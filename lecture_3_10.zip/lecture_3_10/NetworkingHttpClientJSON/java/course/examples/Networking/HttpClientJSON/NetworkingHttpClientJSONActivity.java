package course.examples.Networking.HttpClientJSON;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

public class NetworkingHttpClientJSONActivity extends ListActivity {

	private static final String USER_NAME = "aporter";
	private static final String URL = "http://api.geonames.org/earthquakesJSON?north=44.1&south=-9.9&east=-22.4&west=55.2&username="
			+ USER_NAME;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		RequestQueue queue = Volley.newRequestQueue(this);
		JsonObjectRequest jsObjRequest = new JsonObjectRequest
				(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
					@Override
					public void onResponse(JSONObject response) {
						try {
							List<String> result=result = parseJson(response);
							setListAdapter(new ArrayAdapter<String>(NetworkingHttpClientJSONActivity.this,
									R.layout.list_item, result));
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
					private List<String> parseJson(JSONObject responseObject) throws JSONException {
						final String LONGITUDE_TAG = "lng";
						final String LATITUDE_TAG = "lat";
						final String MAGNITUDE_TAG = "magnitude";
						final String EARTHQUAKE_TAG = "earthquakes";
						List<String> result = new ArrayList<String>();
						JSONArray earthquakes = responseObject.getJSONArray(EARTHQUAKE_TAG);
						for (int idx = 0; idx < earthquakes.length(); idx++) {
							// Get single earthquake data - a Map
							JSONObject earthquake = (JSONObject) earthquakes.get(idx);
							// Summarize earthquake data as a string and add it to
							// result
							result.add(MAGNITUDE_TAG + ":"
									+ earthquake.get(MAGNITUDE_TAG) + ","
									+ LATITUDE_TAG + ":"
									+ earthquake.getString(LATITUDE_TAG) + ","
									+ LONGITUDE_TAG + ":"
									+ earthquake.get(LONGITUDE_TAG));
						}
						return result;
					}
				}, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error) {
						// TODO Auto-generated method stub
					}
				});

		queue.add(jsObjRequest);
	}

}