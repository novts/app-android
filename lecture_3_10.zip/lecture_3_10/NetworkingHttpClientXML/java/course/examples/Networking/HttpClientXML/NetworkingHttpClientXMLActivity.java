package course.examples.Networking.HttpClientXML;

import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import android.app.ListActivity;;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class NetworkingHttpClientXMLActivity extends ListActivity {

	private static final String USER_NAME = "aporter";
	private static final String URL = "http://api.geonames.org/earthquakes?north=44.1&south=-9.9&east=-22.4&west=55.2&username="
			+ USER_NAME;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		RequestQueue queue = Volley.newRequestQueue(this);
		// Request a string response from the provided URL.
		StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
				new Response.Listener<String>() {

					private static final String MAGNITUDE_TAG = "magnitude";
					private static final String LONGITUDE_TAG = "lng";
					private static final String LATITUDE_TAG = "lat";
					private String mLat, mLng, mMag;
					private boolean mIsParsingLat, mIsParsingLng, mIsParsingMag;
					private final List<String> mResults = new ArrayList<String>();

					@Override
					public void onResponse(String response) {
						List<String> result= null;
						try {
							result = parseXML(response);
							setListAdapter(new ArrayAdapter<String>(
									NetworkingHttpClientXMLActivity.this,
									R.layout.list_item, result));
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

					private List<String> parseXML(String response) throws Exception {
                        // Create the Pull Parser
						XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
						XmlPullParser xpp = factory.newPullParser();
						xpp.setInput(new StringReader( response ));
						// Get the first Parser event and start iterating over the XML document
						int eventType = xpp.getEventType();

						while (eventType != XmlPullParser.END_DOCUMENT) {

							if (eventType == XmlPullParser.START_TAG) {
								startTag(xpp.getName());
							} else if (eventType == XmlPullParser.END_TAG) {
								endTag(xpp.getName());
							} else if (eventType == XmlPullParser.TEXT) {
								text(xpp.getText());
							}
							eventType = xpp.next();
						}
						return mResults;
					}
					private void startTag(String localName) {
						if (localName.equals(LATITUDE_TAG)) {
							mIsParsingLat = true;
						} else if (localName.equals(LONGITUDE_TAG)) {
							mIsParsingLng = true;
						} else if (localName.equals(MAGNITUDE_TAG)) {
							mIsParsingMag = true;
						}
					}

					private void text(String text) {
						if (mIsParsingLat) {
							mLat = text.trim();
						} else if (mIsParsingLng) {
							mLng = text.trim();
						} else if (mIsParsingMag) {
							mMag = text.trim();
						}
					}

					private void endTag(String localName) {
						if (localName.equals(LATITUDE_TAG)) {
							mIsParsingLat = false;
						} else if (localName.equals(LONGITUDE_TAG)) {
							mIsParsingLng = false;
						} else if (localName.equals(MAGNITUDE_TAG)) {
							mIsParsingMag = false;
						} else if (localName.equals("earthquake")) {
							mResults.add(MAGNITUDE_TAG + ":" + mMag + "," + LATITUDE_TAG + ":"
									+ mLat + "," + LONGITUDE_TAG + ":" + mLng);
							mLat = null;
							mLng = null;
							mMag = null;
						}
					}
				}, new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {

			}
		});
// Add the request to the RequestQueue.
		queue.add(stringRequest);
	}
}