package course.examples.Networking.AndroidHttpClient;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class NetworkingAndroidHttpClientActivity extends Activity {
	private TextView mTextView = null;
	private Context context;
	private static final String USER_NAME = "aporter";
	private static final String URL = "http://api.geonames.org/earthquakesJSON?north=44.1&south=-9.9&east=-22.4&west=55.2&username="
			+ USER_NAME;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		context=this;

		mTextView = (TextView) findViewById(R.id.textView1);

		final Button loadButton = (Button) findViewById(R.id.button1);
		loadButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				RequestQueue queue = Volley.newRequestQueue(context);
				StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
						new Response.Listener<String>() {
							@Override
							public void onResponse(String response) {
								mTextView.setText(response);
							}
						}, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error) {
						mTextView.setText("That didn't work!");
					}
				});
// Add the request to the RequestQueue.
				queue.add(stringRequest);
			}
		});
	}

}