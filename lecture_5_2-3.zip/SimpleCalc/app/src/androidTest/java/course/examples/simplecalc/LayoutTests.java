package course.examples.simplecalc;

import android.graphics.Rect;
import android.view.View;
import android.widget.Button;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class LayoutTests {

    private Button addValues;
    private Button multiplyValues;
    private View mainLayout;

    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule(MainActivity.class);

    @Before
    public void setUp() {

        MainActivity mainActivity = mActivityRule.getActivity();
        addValues = (Button) mainActivity.findViewById(R.id.addValues);
        multiplyValues = (Button) mainActivity
                .findViewById(R.id.multiplyValues);
        mainLayout = (View) mainActivity.findViewById(R.id.mainLayout);

    }
    @Test
    public void testAddButtonOnScreen() {
        int fullWidth = mainLayout.getWidth();
        int fullHeight = mainLayout.getHeight();
        int[] mainLayoutLocation = new int[2];
        mainLayout.getLocationOnScreen(mainLayoutLocation);

        int[] viewLocation = new int[2];
        addValues.getLocationOnScreen(viewLocation);

        Rect outRect = new Rect();
        addValues.getDrawingRect(outRect);

        assertTrue("Add button off the right of the screen", fullWidth
                + mainLayoutLocation[0] > outRect.width() + viewLocation[0]);
        assertTrue("Add button off the bottom of the screen", fullHeight
                + mainLayoutLocation[1] > outRect.height() + viewLocation[1]);
    }

    @Test
    public void testMultiplyButtonOnScreen() {
        int fullWidth = mainLayout.getWidth();
        int fullHeight = mainLayout.getHeight();
        int[] mainLayoutLocation = new int[2];
        mainLayout.getLocationOnScreen(mainLayoutLocation);

        int[] viewLocation = new int[2];
        multiplyValues.getLocationOnScreen(viewLocation);

        Rect outRect = new Rect();
        multiplyValues.getDrawingRect(outRect);

        assertTrue("Multiply button off the right of the screen", fullWidth
                + mainLayoutLocation[0] > outRect.width() + viewLocation[0]);
        assertTrue("Multiply button off the bottom of the screen", fullHeight
                + mainLayoutLocation[1] > outRect.height() + viewLocation[1]);
    }
}

