/*
 * Copyright (c) 2010, Lauren Darcey and Shane Conder
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are 
 * permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this list of 
 *   conditions and the following disclaimer.
 *   
 * * Redistributions in binary form must reproduce the above copyright notice, this list 
 *   of conditions and the following disclaimer in the documentation and/or other 
 *   materials provided with the distribution.
 *   
 * * Neither the name of the <ORGANIZATION> nor the names of its contributors may be used
 *   to endorse or promote products derived from this software without specific prior 
 *   written permission.
 *   
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF 
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * <ORGANIZATION> = Mamlambo
 */
package course.examples.simplecalc;

import android.widget.TextView;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class MathValidation {

    private TextView result;

    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule(MainActivity.class);

    @Before
    public void setUp() {

        MainActivity mainActivity = mActivityRule.getActivity();
        result = (TextView) mainActivity.findViewById(R.id.result);
    }

    private static final String NUMBER_24 = "24";
    private static final String NUMBER_74 = "74";
    private static final String NUMBER_5_DOT_5 = "5.5";
    private static final String NUMBER_NEG_22 = "-22";

    private static final String ADD_RESULT = "98";
    private static final String ADD_DECIMAL_RESULT = "79.5";
    private static final String ADD_NEGATIVE_RESULT = "52";
    private static final String MULTIPLY_RESULT = "1776";

    @Test
    public void testAddDecimalValues() {

      //  onView(withId(R.id.value1)).perform(typeText(NUMBER_5_DOT_5), closeSoftKeyboard());
        onView(withId(R.id.value1)).perform(typeText(NUMBER_24), closeSoftKeyboard());
        onView(withId(R.id.value2)).perform(typeText(NUMBER_74), closeSoftKeyboard());
        onView(withId(R.id.addValues)).perform(click());
        String mathResult = result.getText().toString();
     //   assertTrue("Add result should be " + ADD_DECIMAL_RESULT + " but was " + mathResult, mathResult.equals(ADD_DECIMAL_RESULT));
      //  onView(withId(R.id.result)).check(matches(withText(ADD_DECIMAL_RESULT)));
        onView(withId(R.id.result)).check(matches(withText(ADD_RESULT)));
    }

    @Test
    public void testSubtractValues() {

        onView(withId(R.id.value1)).perform(typeText(NUMBER_NEG_22), closeSoftKeyboard());
        onView(withId(R.id.value2)).perform(typeText(NUMBER_74), closeSoftKeyboard());
        onView(withId(R.id.addValues)).perform(click());
        String mathResult = result.getText().toString();
        assertTrue("Add result should be " + ADD_NEGATIVE_RESULT + " but was "  + mathResult, mathResult.equals(ADD_NEGATIVE_RESULT));
        onView(withId(R.id.result)).check(matches(withText(ADD_NEGATIVE_RESULT)));
    }
}