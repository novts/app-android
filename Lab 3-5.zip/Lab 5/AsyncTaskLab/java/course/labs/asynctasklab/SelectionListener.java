package course.labs.asynctasklab;

interface SelectionListener {
	public void onItemSelected(int position);
	public boolean canAllowUserClicks();
}