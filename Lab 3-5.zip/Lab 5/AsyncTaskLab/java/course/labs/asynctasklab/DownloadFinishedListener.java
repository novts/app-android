package course.labs.asynctasklab;

interface DownloadFinishedListener {
	void notifyDataRefreshed(String[] feeds);
}
