package course.examples.fragments.staticconfiglayout;

interface ListSelectionListener {
    void onListSelection(int index);
}
