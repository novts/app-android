package course.examples.helloandroid;

import android.widget.TextView;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)

public class HelloAndroidTest {

	private HelloAndroid mActivity;
	private TextView mView;
	private String resourceString;

	@Rule
	public ActivityTestRule<HelloAndroid> mActivityRule = new ActivityTestRule(HelloAndroid.class);

	@Before
	public void setUp() {
		mActivity = mActivityRule.getActivity();
		mView = (TextView) mActivity.findViewById(course.examples.helloandroid.R.id.textview);
		resourceString = mActivity
				.getString(course.examples.helloandroid.R.string.hello);
	}
	@Test
	public void testPreconditions() { assertNotNull(mView);
	}
	@Test
	public void testText() { assertEquals(resourceString,(String)mView.getText());
	}}
